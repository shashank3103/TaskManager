package fsd.taskmgr.sg.entities;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="tblTask")
public class Task {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long taskId;
	
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="parentId")
	private Task parentTask;

	private String task;
	private String startDate;
	private String endDate;
	private int priority;
	
	public long getTaskId() {
		return taskId;
	}

	public void setTaskId(long taskId) {
		this.taskId = taskId;
	}

	public Task getParentTask() {
		return parentTask;
	}
	
	

	public void setParentTask(Task parentTask) {
		this.parentTask = parentTask;
	}

	public String getTask() {
		return task;
	}

	public void setTask(String task) {
		this.task = task;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public int getPriority() {
		return priority;
	}

	public void setPriority(int priority) {
		this.priority = priority;
	}
	
	public Task() {}

	public Task(Task parentTask, String task) {
		
		this.parentTask = parentTask;
		this.task = task;
	}	
		
}
