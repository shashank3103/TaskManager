package fsd.taskmgr.sg.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import fsd.taskmgr.sg.entities.Task;

public interface TaskRepository extends JpaRepository<Task, Long>{

}
