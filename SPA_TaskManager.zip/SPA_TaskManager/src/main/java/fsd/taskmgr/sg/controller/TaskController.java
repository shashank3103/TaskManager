package fsd.taskmgr.sg.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import fsd.taskmgr.sg.entities.Task;
import fsd.taskmgr.sg.repository.TaskRepository;

@RestController
@RequestMapping("/spa")
@CrossOrigin(origins="http://localhost:4200", allowedHeaders="*")
public class TaskController {
	@Autowired
	private TaskRepository taskRepository;

	@GetMapping("/tasks")
	public List<Task> getTasks() {
		return taskRepository.findAll();
	}

	@GetMapping("/task/{id}")
	public Optional<Task> getTask(@PathVariable Long id) {
		return taskRepository.findById(id);
	}

	@DeleteMapping("/task/{id}")
	public boolean deleteTask(@PathVariable Long id) {
		taskRepository.deleteById(id);
		return true;
	}

	@PutMapping("/task")
	public Task updateTask(@RequestBody Task task) {
		return taskRepository.save(task);
	}

	@PostMapping("/task")
	public Task createTask(@RequestBody Task task) {
		return taskRepository.save(task);
	}
}
