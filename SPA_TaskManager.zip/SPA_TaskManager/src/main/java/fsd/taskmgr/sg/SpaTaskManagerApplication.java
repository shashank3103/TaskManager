package fsd.taskmgr.sg;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import fsd.taskmgr.sg.entities.Task;
import fsd.taskmgr.sg.repository.TaskRepository;

/*@SpringBootApplication
public class SpaTaskManagerApplication{

	@Autowired
	private TaskRepository taskRepository;
	
	public static void main(String[] args) {
		SpringApplication.run(SpaTaskManagerApplication.class, args);
	}
}*/

@SpringBootApplication
public class SpaTaskManagerApplication implements CommandLineRunner{

	@Autowired
	private TaskRepository taskRepository;
	//private  TaskController taskController = new TaskController();
	
	//List<Task>  arrTask;
	
	public static void main(String[] args) {
		SpringApplication.run(SpaTaskManagerApplication.class, args);
	}
	
	@Override
	public void run(String... args) throws Exception {
		Task task = new Task();
		task.setTask("running");
		
		Task ptask=new Task();
		ptask.setTask("walking");
		ptask.setParentTask(task);
		
		taskRepository.save(ptask);
		
		//Task ptask1=new Task();
		//ptask1.setTask("skipping");
		//ptask1.setParentTask(task);
		
		//taskRepository.save(ptask1);
		
		//arrTask= taskRepository.findAll();
		
		//System.out.println((taskRepository.findById((long)26)).get().getParentTask().getTask());
		
		//System.out.println(taskRepository.findOne(task.getParentTask()));
		
		//for (int i=0 ; i<arrTask.size(); i++) 
		//{
			
		      //System.out.println("ParentID" + (arrTask.get(i).getParentTask().getTask()));
		//}
		
		// taskRepository.save(null,new Task("run"));
		//taskRepository.save(new Task("skipping",2));
		//taskRepository.save(new Task("cycling",3));	
	}
}
