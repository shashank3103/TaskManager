package fsd.taskmgr.sg.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tblParent")
public class ParentTask {

	@Id
	@GeneratedValue
	private long parentId;
	
	private String parentTask;
	
	public long getParentId() {
		return parentId;
	}

	public void setParentId(long parentId) {
		this.parentId = parentId;
	}

	public String getParentTask() {
		return parentTask;
	}

	public void setParentTask(String parentTask) {
		this.parentTask = parentTask;
	}

	public ParentTask(long parentId, String parentTask) {
		this.parentId = parentId;
		this.parentTask = parentTask;
	}

	
}
